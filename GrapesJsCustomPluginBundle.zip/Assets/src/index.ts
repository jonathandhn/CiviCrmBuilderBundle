import grapesjs from 'grapesjs';

declare global {
    interface Window {
        MauticGrapesJsPlugins: object[];
    }
}

export type PluginOptions = {};
export type RequiredPluginOptions = Required<PluginOptions>;

const GrapesJsCustomPlugin: grapesjs.Plugin<PluginOptions> = (
    editor,
    opts: Partial<PluginOptions> = {}
) => {
    const options: RequiredPluginOptions = { ...opts };
    console.log('Run GrapesJsCustomPlugin (SOS Homophobie - Modular Edition)...', options);

    editor.on('load', () => {
        const blockManager = editor.BlockManager;

        const categoryMautic = { id: 'sos-mautic', label: 'Mautic', open: true, order: 1 };
        const categoryElements = { id: 'sos-elements', label: 'Générique - Éléments', open: true, order: 2 };
        const categoryStructures = { id: 'sos-structures', label: 'Générique - Structures', open: true, order: 3 };

        blockManager.getCategories().add(categoryMautic);
        blockManager.getCategories().add(categoryElements);
        blockManager.getCategories().add(categoryStructures);

        const style = document.createElement('style');
        style.innerHTML = `
      .gjs-block {
        font-family: Roboto, Arial, sans-serif;
      }

      .gjs-block svg {
        color: #ea148c;
        margin-bottom: 6px;
      }

      .gjs-block-label {
        font-size: 12px;
        line-height: 1.25;
      }
    `;
        document.head.appendChild(style);

        const iconText = `
      <svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
        <path fill="currentColor" d="M4 5h16v2H4V5zm0 4h16v2H4V9zm0 4h10v2H4v-2zm0 4h16v2H4v-2z"/>
      </svg>
    `;

        const iconHeader = `
      <svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
        <path fill="currentColor" d="M3 5h18v5H3V5zm2 2v1h14V7H5zm-2 6h18v6H3v-6zm2 2v2h14v-2H5z"/>
      </svg>
    `;

        const iconButton = `
      <svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
        <path fill="currentColor" d="M5 8h14a4 4 0 0 1 0 8H5a4 4 0 0 1 0-8zm0 2a2 2 0 0 0 0 4h14a2 2 0 0 0 0-4H5z"/>
      </svg>
    `;

        const iconDivider = `
      <svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
        <path fill="currentColor" d="M4 11h16v2H4v-2z"/>
      </svg>
    `;

        const iconSpacer = `
      <svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
        <path fill="currentColor" d="M11 3h2v18h-2V3zM7 5l5-5 5 5h-3v3h-4V5H7zm10 14l-5 5-5-5h3v-3h4v3h3z"/>
      </svg>
    `;

        const iconColumns = `
      <svg viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
        <path fill="currentColor" d="M3 5h5v14H3V5zm7 0h4v14h-4V5zm6 0h5v14h-5V5z"/>
      </svg>
    `;

        const sectionStyle = 'background-color="#ffffff" padding="0"';
        const sectionWithBorder = 'background-color="#ffffff" border-bottom="2px solid #808080" padding="0"';

        blockManager.add('sos-webview-link', {
            label: 'Lien navigateur',
            category: categoryMautic,
            media: iconText,
            content: `
        <mj-section background-repeat="repeat" padding="0px" text-align="center">
          <mj-column>
            <mj-text align="left" color="#000000" font-family="Roboto, sans-serif" font-size="10px" letter-spacing="0px" padding="0px 15px">
              <p style="text-align: right; margin: 10px 0;"><a style="color:inherit;text-decoration:none" target="_blank" href="{webview_url}"><span style="color:#ea148c;font-family:Roboto, sans-serif;font-size:10px;">{webview_text}</span></a></p>
            </mj-text>
          </mj-column>
        </mj-section>
      `,
        });

        blockManager.add('sos-header', {
            label: 'Header SOS',
            category: categoryMautic,
            media: iconHeader,
            content: `
        <mj-section background-color="#ea148c" background-repeat="repeat" padding="15px" text-align="center">
          <mj-column vertical-align="middle" width="25%">
            <mj-image align="center" alt="" border-radius="0" border="none" fluid-on-mobile="false" height="auto" href="https://www.sos-homophobie.org" padding="0px" src="https://ressource.sos-homophobie.org/graphismes/socle/logos/logo_magenta.png" target="_blank" title="SOS homophobie" width="1077px"></mj-image>
          </mj-column>
          <mj-column vertical-align="middle" width="75%">
            <mj-text align="left" color="#000000" font-family="Roboto, sans-serif" font-size="13px" letter-spacing="0px" padding="10px 25px">
              <h1 style="text-align:center; margin: 10px 0"><span style="color:#ffffff;font-family:Roboto, sans-serif;font-size:20px;"><b>{subject}</b></span></h1>
            </mj-text>
          </mj-column>
        </mj-section>
      `,
        });

        blockManager.add('sos-unsubscribe', {
            label: 'Désinscription section',
            category: categoryMautic,
            media: iconText,
            content: `
        <mj-section background-repeat="repeat" padding="0px" text-align="center">
          <mj-column>
            <mj-text align="left" color="#000000" font-family="Roboto, sans-serif" font-size="10px" letter-spacing="0px" padding="0px 0px 20px 0px">
              <p style="text-align: center; margin: 10px 0;"><a style="color:inherit;text-decoration:none" target="_blank" href="{unsubscribe_url}"><span style="color:#ea148c;font-family:Roboto, sans-serif;font-size:10px;">{unsubscribe_text}</span></a></p>
            </mj-text>
          </mj-column>
        </mj-section>
      `,
        });

        blockManager.add('sos-unsubscribe-module', {
            label: 'Désinscription module',
            category: categoryMautic,
            media: iconText,
            content: `
        <mj-text align="center" color="#000000" font-family="Roboto, sans-serif" font-size="10px" letter-spacing="0px" padding="10px 25px">
          <p style="text-align: center; margin: 0;"><a style="color:inherit;text-decoration:none" target="_blank" href="{unsubscribe_url}"><span style="color:#ea148c;font-family:Roboto, sans-serif;font-size:10px;">{unsubscribe_text}</span></a></p>
        </mj-text>
      `,
        });

        blockManager.add('sos-title', {
            label: 'Titre',
            category: categoryElements,
            media: iconText,
            content: `
        <mj-text align="left" color="#000000" font-family="Roboto, sans-serif" font-size="13px" letter-spacing="0px" padding="10px 25px">
          <h2 style="margin-top: 10px; margin-bottom: 10px"><span style="color:#ea148c;font-family:Roboto, sans-serif;font-size:18px;"><b>Titre de votre section</b></span></h2>
        </mj-text>
      `,
        });

        blockManager.add('sos-text', {
            label: 'Texte',
            category: categoryElements,
            media: iconText,
            content: `
        <mj-text align="left" color="#000000" font-family="Roboto, sans-serif" font-size="13px" letter-spacing="0px" padding="10px 25px">
          <p style="margin: 10px 0;"><span style="color:#00577b;font-family:Roboto, sans-serif;font-size:13px;line-height:22px;">Votre contenu ici...</span></p>
        </mj-text>
      `,
        });

        blockManager.add('sos-divider', {
            label: 'Séparateur',
            category: categoryElements,
            media: iconDivider,
            content: `
        <mj-divider border-color="#ea148c" border-style="solid" border-width="2px" padding="10px 0px" width="80%"></mj-divider>
      `,
        });

        blockManager.add('sos-button', {
            label: 'Bouton',
            category: categoryElements,
            media: iconButton,
            content: `
        <mj-button align="left" background-color="#ea148c" border-radius="0px" border="0px solid #ffffff" color="#ffffff" container-background-color="transparent" font-family="Roboto, sans-serif" font-size="13px" font-weight="normal" href="#" inner-padding="10px 25px 10px 25px" padding="8px 25px" text-decoration="none" text-transform="none" vertical-align="middle">
          <span style="color:#ffffff;font-family:Roboto, sans-serif;font-size:14px;"><b>Bouton</b></span>
        </mj-button>
      `,
        });

        blockManager.add('sos-spacer', {
            label: 'Espaceur',
            category: categoryElements,
            media: iconSpacer,
            content: `
        <mj-spacer height="15px"></mj-spacer>
      `,
        });

        blockManager.add('sos-section-1-border', {
            label: 'Section 1 col bordure',
            category: categoryStructures,
            media: iconColumns,
            content: `<mj-section ${sectionWithBorder}><mj-column></mj-column></mj-section>`,
        });

        blockManager.add('sos-section-1', {
            label: 'Section 1 col',
            category: categoryStructures,
            media: iconColumns,
            content: `<mj-section ${sectionStyle}><mj-column></mj-column></mj-section>`,
        });

        blockManager.add('sos-section-2', {
            label: 'Section 2 cols',
            category: categoryStructures,
            media: iconColumns,
            content: `<mj-section ${sectionStyle}><mj-column></mj-column><mj-column></mj-column></mj-section>`,
        });

        blockManager.add('sos-section-3', {
            label: 'Section 3 cols',
            category: categoryStructures,
            media: iconColumns,
            content: `<mj-section ${sectionStyle}><mj-column></mj-column><mj-column></mj-column><mj-column></mj-column></mj-section>`,
        });

        blockManager.add('sos-section-25-75', {
            label: 'Section 25-75',
            category: categoryStructures,
            media: iconColumns,
            content: `<mj-section ${sectionStyle}><mj-column width="25%"></mj-column><mj-column width="75%"></mj-column></mj-section>`,
        });

        blockManager.add('sos-footer', {
            label: 'Footer',
            category: categoryStructures,
            media: iconText,
            content: `
        <mj-section background-repeat="repeat" padding="20px 0" text-align="center">
          <mj-column>
            <mj-divider border-color="#ea148c" border-style="solid" border-width="2px" padding="10px 0px" width="80%"></mj-divider>
            <mj-text align="center" color="#787878" font-family="Roboto, sans-serif" font-size="13px" padding="0px">
              <p style="margin: 10px 0;">Association de lutte contre la lesbophobie, la gayphobie, la biphobie, et la transphobie<br>Association loi 1901 créée le 11 avril 1994</p>
              <p style="margin: 10px 0;"><b>SOS homophobie</b><br>14 rue Abel<br>75012 Paris</p>
            </mj-text>
            <mj-image align="center" alt="Ligne d'écoute anonyme : 01 48 06 42 41" border="none" height="auto" width="300px" href="https://www.sos-homophobie.org/ligne-ecoute" padding="0px" src="https://ressource.sos-homophobie.org/graphismes/ecoute/cartouche_ecouche.png" target="_blank" title="Ligne d'écoute anonyme"></mj-image>
          </mj-column>
        </mj-section>
      `,
        });
    });
};

export default GrapesJsCustomPlugin;

if (!window.MauticGrapesJsPlugins) window.MauticGrapesJsPlugins = [];

window.MauticGrapesJsPlugins.push({
    name: 'GrapesJsCustomPlugin',
    plugin: GrapesJsCustomPlugin,
    context: ['page', 'email-mjml'],
    pluginOptions: { options: { test: true } },
});